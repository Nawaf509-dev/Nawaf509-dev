import React, { useState } from 'react';
    import { useTranslation } from 'react-i18next';

    function Contact() {
      const { t } = useTranslation();
      const [email, setEmail] = useState('');
      const [message, setMessage] = useState('');
      const [status, setStatus] = useState('');

      const handleSubmit = (e) => {
        e.preventDefault();
        if (!email || !message) {
          setStatus(t('fill_all_fields'));
          return;
        }
        setStatus(t('message_sent_successfully'));
        setEmail('');
        setMessage('');
      };

      return (
        <div>
          <h2>{t('contact_us')}</h2>
          <form className="contact-form" onSubmit={handleSubmit}>
            <label>{t('email')}:</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            <label>{t('message')}:</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            />

            <button type="submit">{t('send_message')}</button>
          </form>
          {status && <div className="result">{status}</div>}
        </div>
      );
    }

    export default Contact;
