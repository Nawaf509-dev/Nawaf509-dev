import React, { useState } from 'react';
    import { Pie } from 'react-chartjs-2';
    import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
    import { useTranslation } from 'react-i18next';

    ChartJS.register(ArcElement, Tooltip, Legend);

    function Home() {
      const { t } = useTranslation();
      const [weight, setWeight] = useState('');
      const [height, setHeight] = useState('');
      const [age, setAge] = useState('');
      const [gender, setGender] = useState('male');
      const [activityLevel, setActivityLevel] = useState('low');
      const [result, setResult] = useState('');
      const [macros, setMacros] = useState(null);
      const [weightPlan, setWeightPlan] = useState(null);
      const [showWeightPlan, setShowWeightPlan] = useState(false);
      const [selectedGoal, setSelectedGoal] = useState('loss');

      const calculateCalories = () => {
        if (!weight || !height || !age) {
          setResult(t('fill_all_fields'));
          return;
        }

        const weightKg = parseFloat(weight);
        const heightCm = parseFloat(height);
        const ageYears = parseInt(age, 10);

        let bmr;
        if (gender === 'male') {
          bmr = 10 * weightKg + 6.25 * heightCm - 5 * ageYears + 5;
        } else {
          bmr = 10 * weightKg + 6.25 * heightCm - 5 * ageYears - 161;
        }

        let activityMultiplier;
        switch (activityLevel) {
          case 'low':
            activityMultiplier = 1.2;
            break;
          case 'medium':
            activityMultiplier = 1.55;
            break;
          case 'high':
            activityMultiplier = 1.725;
            break;
          default:
            activityMultiplier = 1.2;
        }

        const dailyCalories = Math.round(bmr * activityMultiplier);
        setResult(
          `${t('estimated_daily_calories')} ${dailyCalories} ${t('calories')}`,
        );

        // Calculate macros (balanced approach)
        let proteinGrams, carbGrams, fatGrams;

        if (selectedGoal === 'loss') {
          proteinGrams = Math.round((dailyCalories * 0.4) / 4);
          carbGrams = Math.round((dailyCalories * 0.3) / 4);
          fatGrams = Math.round((dailyCalories * 0.3) / 9);
        } else if (selectedGoal === 'gain') {
          proteinGrams = Math.round((dailyCalories * 0.35) / 4);
          carbGrams = Math.round((dailyCalories * 0.4) / 4);
          fatGrams = Math.round((dailyCalories * 0.25) / 9);
        } else {
          proteinGrams = Math.round((dailyCalories * 0.3) / 4);
          carbGrams = Math.round((dailyCalories * 0.4) / 4);
          fatGrams = Math.round((dailyCalories * 0.3) / 9);
        }

        setMacros({
          protein: proteinGrams,
          carbs: carbGrams,
          fat: fatGrams,
        });

        // Calculate weight plan
        const weightChangeCalories = {
          loss: {
            '0.25 kg': dailyCalories - 250,
            '0.5 kg': dailyCalories - 500,
            '1 kg': dailyCalories - 1000,
          },
          maintain: {
            '0 kg': dailyCalories,
          },
          gain: {
            '0.25 kg': dailyCalories + 250,
            '0.5 kg': dailyCalories + 500,
            '1 kg': dailyCalories + 1000,
          },
        };
        setWeightPlan(weightChangeCalories);
      };

      const handleCalculateWeightPlan = () => {
        if (!weightPlan) {
          calculateCalories();
        }
        setShowWeightPlan(true);
      };

      const macroData = macros
        ? {
            labels: [t('protein'), t('carbs'), t('fat')],
            datasets: [
              {
                label: t('macronutrients'),
                data: [macros.protein, macros.carbs, macros.fat],
                backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'],
              },
            ],
          }
        : null;

      return (
        <div>
          <h1>{t('calorie_calculator')}</h1>
          <form>
            <label>{t('weight_kg')}:</label>
            <input
              type="number"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
            />

            <label>{t('height_cm')}:</label>
            <input
              type="number"
              value={height}
              onChange={(e) => setHeight(e.target.value)}
            />

            <label>{t('age_years')}:</label>
            <input
              type="number"
              value={age}
              onChange={(e) => setAge(e.target.value)}
            />

            <div className="radio-group">
              <label>{t('gender')}:</label>
              <input
                type="radio"
                name="gender"
                value="male"
                checked={gender === 'male'}
                onChange={() => setGender('male')}
              />
              <label>{t('male')}</label>
              <input
                type="radio"
                name="gender"
                value="female"
                checked={gender === 'female'}
                onChange={() => setGender('female')}
              />
              <label>{t('female')}</label>
            </div>

            <label>{t('activity_level')}:</label>
            <select
              value={activityLevel}
              onChange={(e) => setActivityLevel(e.target.value)}
            >
              <option value="low">{t('low')}</option>
              <option value="medium">{t('medium')}</option>
              <option value="high">{t('high')}</option>
            </select>

            <button type="button" onClick={calculateCalories}>
              {t('calculate_calories')}
            </button>
          </form>
          {result && <div className="result">{result}</div>}

          {macros && (
            <div className="macros">
              <h3>{t('macronutrient_needs')}</h3>
              <ul className="macros-list">
                <li>
                  {t('protein')}: {macros.protein} {t('grams')}
                </li>
                <li>
                  {t('carbs')}: {macros.carbs} {t('grams')}
                </li>
                <li>
                  {t('fat')}: {macros.fat} {t('grams')}
                </li>
              </ul>
              <div style={{ width: '200px', margin: '0 auto' }}>
                <Pie data={macroData} />
              </div>
            </div>
          )}

          {showWeightPlan && weightPlan && (
            <div className="weight-plan">
              <h3>{t('weight_plan')}</h3>
              <select
                value={selectedGoal}
                onChange={(e) => setSelectedGoal(e.target.value)}
              >
                <option value="loss">{t('weight_loss')}</option>
                <option value="maintain">{t('maintain_weight')}</option>
                <option value="gain">{t('weight_gain')}</option>
              </select>
              <table className="weight-table">
                <thead>
                  <tr>
                    <th>{t('weekly_goal')}</th>
                    <th>{t('daily_calories')}</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(weightPlan[selectedGoal]).map(
                    ([goal, calories]) => (
                      <tr key={goal}>
                        <td>{goal}</td>
                        <td>{calories} {t('calories')}</td>
                      </tr>
                    ),
                  )}
                </tbody>
              </table>
            </div>
          )}
          {!showWeightPlan && (
            <button onClick={handleCalculateWeightPlan}>
              {t('calculate_weight_plan')}
            </button>
          )}

          <div className="additional-tips">
            <h3>{t('nutrition_tips')}</h3>
            <ul>
              <li>{t('protein_rich_meals')}</li>
              <li>{t('drink_water')}</li>
            </ul>
          </div>

          <div className="exercise-reminder">
            <h3>{t('exercise_reminder')}</h3>
            <p>{t('exercise_recommendation')}</p>
            <p>
              {t('check_out_videos')}{' '}
              <a
                href="https://www.youtube.com/results?search_query=easy+exercises"
                target="_blank"
                rel="noopener noreferrer"
              >
                {t('easy_exercise_videos')}
              </a>
              .
            </p>
          </div>
        </div>
      );
    }

    export default Home;
