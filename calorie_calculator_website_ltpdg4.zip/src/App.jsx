import React from 'react';
    import { Routes, Route, Link } from 'react-router-dom';
    import Home from './components/Home';
    import About from './components/About';
    import Contact from './components/Contact';
    import { useTranslation } from 'react-i18next';

    function App() {
      const { t, i18n } = useTranslation();

      const changeLanguage = (lng) => {
        i18n.changeLanguage(lng);
      };

      return (
        <div className="container">
          <div className="language-select">
            <select
              onChange={(e) => changeLanguage(e.target.value)}
              defaultValue={i18n.language}
            >
              <option value="en">English</option>
              <option value="ar">العربية</option>
            </select>
          </div>
          <nav>
            <Link to="/">{t('home')}</Link>
            <Link to="/about">{t('about')}</Link>
            <Link to="/contact">{t('contact')}</Link>
          </nav>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </div>
      );
    }

    export default App;
